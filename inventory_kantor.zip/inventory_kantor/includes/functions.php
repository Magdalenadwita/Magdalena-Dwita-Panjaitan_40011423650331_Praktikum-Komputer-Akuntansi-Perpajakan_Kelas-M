<?php
function getAllKategori($conn) {
    $sql = "SELECT * FROM kategori ORDER BY nama_kategori";
    $result = $conn->query($sql);
    $kategori = [];
    while ($row = $result->fetch_assoc()) {
        $kategori[] = $row;
    }
    return $kategori;
}

function getAllLokasi($conn) {
    $sql = "SELECT * FROM lokasi ORDER BY nama_lokasi";
    $result = $conn->query($sql);
    $lokasi = [];
    while ($row = $result->fetch_assoc()) {
        $lokasi[] = $row;
    }
    return $lokasi;
}

function getAsetByKategori($conn, $id_kategori = null) {
    $sql = "SELECT aset.*, lokasi.nama_lokasi, kategori.nama_kategori 
            FROM aset 
            LEFT JOIN lokasi ON aset.id_lokasi = lokasi.id_lokasi 
            LEFT JOIN kategori ON aset.id_kategori = kategori.id_kategori";

    if ($id_kategori) {
        $sql .= " WHERE aset.id_kategori = " . intval($id_kategori);
    }
    $sql .= " ORDER BY aset.nama_barang";

    $result = $conn->query($sql);
    $data = [];
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
    return $data;
}
?>
