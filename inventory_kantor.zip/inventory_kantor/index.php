<!DOCTYPE html>
<html>
<head><style>
  body {
    background-color: #e0f0ff; /* Biru muda, bisa ganti jadi #007bff untuk biru pekat */
    font-family: Arial, sans-serif;
  }

  h1 {
    color: #003366;
  }

  table {
    border-collapse: collapse;
    width: 100%;
    background-color: white; /* supaya tabel tetap putih */
  }

  th {
    background-color: #007bff;
    color: white;
    padding: 8px;
  }

  td {
    padding: 6px;
    border: 1px solid #ccc;
  }

  .nama {
    font-weight: bold;
    margin-bottom: 10px;
    color: #003366;
  }
</style>


    <title>Inventory Kantor</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <h1>DATA INVENTARIS KANTOR</h1>
<p>Nama: Magdalena Dwita</p>

    <div>
        <label>Kategori:</label>
        <select id="filterKategori">
            <option value="">Semua</option>
        </select>
        <button onclick="loadData()">Tampil</button>
    </div>
    <table id="tabelAset">
        <thead>
            <tr>
                <th>No</th>
                <th>Kode Label</th>
                <th>Nomor Seri</th>
                <th>Nama Barang</th>
                <th>Status</th>
                <th>Lokasi</th>
                <th>Tools</th>
            </tr>
        </thead>
        <tbody></tbody>
    </table>
    <script src="assets/js/script.js"></script>
</body>
</html>
