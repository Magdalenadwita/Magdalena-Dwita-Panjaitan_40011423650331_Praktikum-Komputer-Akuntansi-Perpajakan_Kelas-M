function loadData() {
  fetch("pages/inventaris.php")
    .then((response) => response.json())
    .then((data) => {
      const tbody = document.querySelector("#tabelAset tbody");
      tbody.innerHTML = "";
      data.forEach((item, index) => {
        const row = `<tr>
                    <td>${index + 1}</td>
                    <td>${item.kode_label}</td>
                    <td>${item.nomor_seri}</td>
                    <td>${item.nama_barang}</td>
                    <td>${item.status}</td>
                    <td>${item.nama_lokasi}</td>
                    <td>
                        <a href="#">Pemeliharaan</a> |
                        <a href="#">Resume</a> |
                        <a href="#">Edit</a>
                    </td>
                </tr>`;
        tbody.insertAdjacentHTML("beforeend", row);
      });
    });
}

window.onload = loadData;
