<?php
include '../includes/db.php';
include '../includes/functions.php';

$id_kategori = isset($_GET['kategori']) ? $_GET['kategori'] : null;
$data = getAsetByKategori($conn, $id_kategori);
echo json_encode($data);
?>
